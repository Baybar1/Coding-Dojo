
function fizzBuzz() {
    for (var i = 1; i <= 99; i++) {
        if (i % 3 == false && i % 5 == false) {
            console.log("FizzBuzz");
        }else if (i % 3 == false){
            console.log("Fizz");
        }else if (i % 5 == false){
            console.log("Buzz");
        }else {
            console.log(i);
        }
    
}
console.log(i);
}

fizzBuzz();